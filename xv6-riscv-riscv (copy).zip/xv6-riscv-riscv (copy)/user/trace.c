#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"

int main()
{
	trace(0);
	exit(1);
}
