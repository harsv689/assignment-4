#include "types.h"
#include "stat.h"
#include "user.h"

int main()
{
	strace(0,0);
	exit(1);
}
